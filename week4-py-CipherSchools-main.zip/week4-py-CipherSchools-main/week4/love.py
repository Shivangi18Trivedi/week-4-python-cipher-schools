with open('love_story.text','r', encoding='utf-8') as f:
    print(f.encoding)
    data = f.read()
    print(data)