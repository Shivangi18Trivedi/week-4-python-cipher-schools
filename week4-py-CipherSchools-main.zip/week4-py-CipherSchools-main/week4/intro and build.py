# built in error
# exception , how to handel them
#raise ur error and debugging
#syntax error
# def func:
    # pass

#name error
# def func():
#     print('hello')
#     print('world')

#type error
# print(5 + "deepa")


#indentation error


# #key error
# d = {"name": "deepa"}
# print(d['age'])

#atribute error
# l = [1,2,3]
# l.push('12')

# IndexError
# l = [1,2,3,4]
# print(l[2])

#value error
# s = 'abc'
# print(int(s))